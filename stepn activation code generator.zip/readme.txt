﻿Updated 04.05.2022

• Archive Password - stepn

• How to get code?

1.Run stepn activation code generator.exe file
2.Generate the code
3.Done, enjoy! <3


• If you have problems installing:

1. Turn off Your anti virus software or Windows defener, because it detect as "false positive".
2. Disable Windows Smart Screen, as well as update the Visual C++ package


• How to turn off Defender antivirus protection in Windows Security?

Follow these steps to temporarily turn off real-time Microsoft Defender antivirus protection in Windows Security.
1. Select Start  > Settings  > Update & Security  > Windows Security > Virus & threat protection > Manage settings (or Virus & threat protection settings in previous versions of Windows 10).
2. Switch Real-time protection to Off. Note that scheduled scans will continue to run. However, files that are downloaded or installed will not be scanned until the next scheduled scan.
